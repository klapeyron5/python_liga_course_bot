from . import linreg
from .utils import ZeroDataException